loadstring(game:GetObjects("rbxassetid://364364477")[1].Source)()
